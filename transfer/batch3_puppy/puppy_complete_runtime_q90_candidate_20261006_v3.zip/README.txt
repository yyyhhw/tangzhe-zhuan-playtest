OPTIONAL WEBP Q90 RUNTIME-SOURCE CANDIDATE - LOSSY RGB

This archive contains derived WebP files, not the authoritative native PNGs.
Alpha and dimensions exactly match each original. Color pixels are lossy.
Use puppy_complete_native_candidates_20261006_v3.zip for unchanged originals.

PUPPY COMPLETE CANDIDATE INVENTORY - CANDIDATE DELIVERY V3

21 derived RGBA WebP Q90 sources, 108 animation candidate frames, plus 3 static standing
references. All 108 target p3 slots are mapped exactly once. This is inventory
coverage, not production approval or a mandatory first-release gate. A preview
can explicitly retain placeholders for any unready action.

No original PNG was changed. These derived files use lossy color encoding only.
Cell selection and scale are unchanged runtime metadata; alpha matches exactly.

CONTENTS
- runtime_manifest.json: clean source, frame, registration, scale and p3 slot data
- reviewer.html / reviewer.js / review_data.js: offline native-source reviewer
- RENDERER_INTEGRATION_OPTION.txt: bounded mixed-preview adapter proposal
- QA_LOCAL.txt: performed checks and untested areas
- sources/: 21 selected images
- SHA256SUMS.txt: per-file integrity checks

Open reviewer.html after extracting the package. It uses local images only.
All 18 animation clips and 3 static references can be selected and played.
The reviewer shows pose sequences only; it does not simulate gameplay, collisions,
ball attachments or the runtime hop-height curve. Browser playback is untested.

REGISTRATION
Conceptual frame: 256x256. Ground: (128,208). p3 runtime: 128px cells, origin
(64,104), displayTiles=1.8. Every action uses ONE constant aspect-preserving scale.
Upright references target 160px conceptual height. Rest keeps lying proportions;
run uses contact-pose scale and virtual ground for suspension. Sniff has a uniform
0.983654 fit factor to retain a 4px conceptual margin throughout the whole action.

sourceRect and groundAnchorLocal are the preferred matched pair. sourceRectInteger
and groundAnchorLocalInteger are a matched alternative. Walks have optional 443.5px
fractional cells. Actions and interactions use measured nonuniform rectangles;
never replace them with equal columns or stretch different cells to equal widths.
In those clips sourceRectUniform is null: an equal-grid fallback is not valid.

QUALITY AND REMAINING WORK
All animations remain candidates. Ground anchors are approximate, mouth anchors
are null/unmeasured, and body envelopes are measured alpha unions but unverified
in gameplay. N walk frame 5 repeats a same-side hind lift. Loop closure, gait,
body swim, paw jitter and cross-state transitions need runtime review.

Run and hop airborne frames use virtual/projected ground so tucked paws remain
above it. Do not snap airborne paws to the floor or apply a second baked jump arc.
Hop runtimeHeightHint is a proposal, not a physics/event implementation.

Some cells have 1-7px padding, notably run E and sleep. Clamp/isolate sampling to
avoid neighbor bleed. Alpha speckles and hidden RGB remain; always preserve alpha.
Eating has only an approximate tongue-target hint, not verified mouth registration.

P3 COMPATIBILITY
This sidecar uses tangzhe-pet-native-candidates/2. It is NOT a drop-in replacement
for tangzhe-pet-art/1. The existing manifest/Animator can remain complete while a
small preview draw adapter selects native frames and visibly falls back for any
unready clip. A final atlas is optional for that preview route, not a prerequisite
to inspecting partial art. No repository code or remote assets were changed here.

Separate final shadow art and per-frame mouth registration are still absent.
Ground/body/ball behavior, source sampling and timing must be tested before final
integration. Candidate timing is separate from pinned p3 timing; generic contact
hints are not p3 events. p3 ball events remain ball_pick and ball_drop.

Q90 ALTERNATIVE
A separate WebP Q90 runtime-source archive may accompany this native package.
That version is explicitly lossy color encoding, preserves dimensions and exact
alpha, and retains identical geometry metadata. Original PNGs are authoritative.
Encoding comparison statistics are included with each source in that archive.

V3 ADDENDUM
Read INTEGRATION_NOTE.txt and anchors_body_v1.json. Thirty E/S facial estimates
and fifteen deliberately null N records are included. These are candidates, not
verified attachment coordinates. Ground-plane depth stays +/-0.22 tile, unrelated
to sprite height. Production mobile use requires the documented build-time atlas.
The complete native source set decodes to 132131736 RGBA bytes; Q90
compression has the same decoded dimensions and does not eliminate that memory.
