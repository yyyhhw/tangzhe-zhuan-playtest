'use strict';
const DATA=window.PUPPY_DATA;
const $=id=>document.getElementById(id);
const canvas=$('canvas'),ctx=canvas.getContext('2d');
const images={},keys=Object.keys(DATA.clips);
let active=keys[0],index=0,playing=false,last=0,elapsed=0;
window.reviewQA={loaded:false,sourceCount:0,frameCount:0,errors:[],renderedFrames:[]};
keys.forEach(key=>{const op=document.createElement('option');op.value=key;op.textContent=key;$('clip').append(op);});
function current(){return DATA.clips[active];}
function sync(){const clip=current();$('position').max=clip.frames.length-1;$('position').value=index;$('frameLabel').textContent=`${index+1} / ${clip.frames.length}`;$('mirror').disabled=clip.dir!=='E';if(clip.dir!=='E')$('mirror').checked=false;}
function render(){
 const clip=current(),f=clip.frames[index],image=images[clip.sourceId];sync();
 ctx.setTransform(2,0,0,2,0,0);ctx.clearRect(0,0,256,256);
 for(let y=0;y<256;y+=16)for(let x=0;x<256;x+=16){ctx.fillStyle=((x+y)/16)%2?'#e8e2d9':'#f7f3ed';ctx.fillRect(x,y,16,16);}
 ctx.strokeStyle='#3b8674';ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(0,208);ctx.lineTo(256,208);ctx.stroke();
 const integer=$('sampling').value==='integer';
 const r=integer?f.sourceRectInteger:f.sourceRect;
 const tr=integer?f.drawFromIntegerToConceptual:f.drawToConceptual;
 ctx.save();if($('mirror').checked){ctx.translate(256,0);ctx.scale(-1,1);}
 if(image)ctx.drawImage(image,r[0],r[1],r[2],r[3],tr.translate[0],tr.translate[1],r[2]*tr.scale,r[3]*tr.scale);
 if($('guides').checked){const b=f.visibleBoundsConceptual;ctx.strokeStyle='#267dbe';ctx.lineWidth=.5;ctx.strokeRect(b[0],b[1],b[2]-b[0],b[3]-b[1]);}
 ctx.restore();
 if($('guides').checked){ctx.strokeStyle='#df4e47';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(122,208);ctx.lineTo(134,208);ctx.moveTo(128,202);ctx.lineTo(128,214);ctx.stroke();}
 $('details').textContent=JSON.stringify({sequence:active,status:clip.status,frame:index+1,source:DATA.sources[clip.sourceId].file,sourceRect:r,sourceGround:integer?f.groundAnchorLocalInteger:f.groundAnchorLocal,conceptualGround:[128,208],fixedScale:clip.nativePxToConceptualScale,frameDurationMs:f.ms,worldVisualSizeTiles:f.visualWorldSizeTiles,groundStatus:f.groundAnchorStatus,mouthStatus:f.mouthAnchorStatus,phase:f.phase||null,virtualGroundY:f.virtualGroundYLocal||null,measuredNonuniformCells:clip.measuredNonuniformCells,caveats:clip.caveats||[]},null,2);
}
function change(key,frame=0){active=key;index=frame;elapsed=0;playing=false;$('clip').value=key;render();}
$('clip').onchange=()=>change($('clip').value);
$('position').oninput=()=>{index=Number($('position').value);elapsed=0;playing=false;render();};
$('play').onclick=()=>{if(index>=current().frames.length-1)index=0;elapsed=0;playing=true;render();};
$('pause').onclick=()=>{playing=false;};
$('previous').onclick=()=>change(active,(index+current().frames.length-1)%current().frames.length);
$('next').onclick=()=>change(active,(index+1)%current().frames.length);
['mirror','guides','sampling'].forEach(id=>$(id).onchange=render);
function tick(now){const delta=last?Math.min(now-last,100):0;last=now;if(playing){elapsed+=delta*Number($('speed').value);while(elapsed>=current().frames[index].ms){elapsed-=current().frames[index].ms;if(index+1<current().frames.length)index++;else if($('loop').checked)index=0;else{playing=false;break;}}render();}requestAnimationFrame(tick);}
Promise.all(Object.entries(DATA.sources).map(([id,s])=>new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>{if(im.naturalWidth!==s.nativeSize[0]||im.naturalHeight!==s.nativeSize[1])return reject(new Error(`Dimensions differ: ${id}`));images[id]=im;resolve();};im.onerror=()=>reject(new Error(`Could not load ${s.file}`));im.src=s.file;}))).then(()=>{
 window.reviewQA.loaded=true;window.reviewQA.sourceCount=Object.keys(images).length;
 for(const key of keys)for(let i=0;i<DATA.clips[key].frames.length;i++){change(key,i);const f=current().frames[index],t=f.drawToConceptual,a=f.groundAnchorLocal;if(Math.abs(t.translate[0]+a[0]*t.scale-128)>1e-6||Math.abs(t.translate[1]+a[1]*t.scale-208)>1e-6)throw new Error('Anchor mismatch');window.reviewQA.renderedFrames.push(`${key}:${i}`);}
 window.reviewQA.frameCount=window.reviewQA.renderedFrames.length;
 const q=new URLSearchParams(location.search);change(q.get('clip')&&DATA.clips[q.get('clip')]?q.get('clip'):keys[0],0);
 $('qa').textContent=`Loaded ${window.reviewQA.sourceCount} Q90 WebP sources (lossy RGB, exact alpha); ${window.reviewQA.frameCount} candidate/reference frames. Motion not approved.`;
 document.body.dataset.ready='1';document.body.dataset.frames=window.reviewQA.frameCount;
 requestAnimationFrame(tick);
}).catch(e=>{window.reviewQA.errors.push(String(e));$('qa').textContent=e.message;document.body.dataset.ready='error';});
